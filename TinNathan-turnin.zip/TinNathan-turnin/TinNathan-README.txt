# NOAA_Satellite

Group members are Tin Vo and Nathan Ngo
